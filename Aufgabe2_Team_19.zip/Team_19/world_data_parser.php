<?php
class WorldDataParser{
	public function parseCSV($path){
		// read csv file part by part, separator is a comma
		$data = array();
		if (($handle = fopen($path, "r")) !== FALSE) {
		  while (($line = fgetcsv($handle, 0, ",")) !== FALSE) {
			array_push($data,$line);
		  }
		  fclose($handle);
		} else {
			echo "error reading file: ".$path;
			return;
		}


		return $data;
	}

	private function addCountry($node,$data,$countryinfo){
		// we add all properties for each country as childs
		$counter = 0;
		foreach( $countryinfo as $key => $value ) {

			$node->addChild(str_replace(' ', '_', trim($data[0][$counter])),trim("$value"));
			$counter = $counter + 1;
		}

	}


	public function  saveXML($data){
		$xml_data = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="world_data.xsl"?><Countries></Countries>');//added something here
		$counter = 0;
		{foreach( $data as $key => $value ) {
			$counter = $counter + 1;
			// first line contains the headers, so we skip it
			if ($counter == 1){
				continue;
			}
			// add each country separatly as a child. add properties as subchilds using addcountry function
			$currentCountryNode = $xml_data->addChild("Country");
			$this->addCountry($currentCountryNode,$data,$value);
		}}

		return $xml_data->asXML('./world_data.xml');

	}




	public function  printXML($xmlFile,$xslFile){
// Load the XML and XSL source
$xml = new DOMDocument;
$xml->load($xmlFile);
$xsl = new DOMDocument;
$xsl->load($xslFile);
// Configure the transformer
$proc = new XSLTProcessor;
// attach the xsl rules
$proc->importStyleSheet($xsl); 
//print the table
echo $proc->transformToXML($xml);

}}
?>
