<!DOCTYPE html>
<html>

<head>
        <meta charset="UTF-8">
        <title>Parsed File</title>
</head>

<body>
        <pre>
                <?php
				
                require('world_data_parser.php');
				//create the parser object and call relevant functions
                $parser = New WorldDataParser();
				//parse file
                $data = $parser->parseCSV("world_data.csv");
		//try to save. If error with writing, let the user know
		if ($parser->saveXML($data,true)){
			echo "saved!";
		} else {
			echo "error saving!";
		}

                ?>

        </pre>
</body>
</html>

