<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<title>Parsed File</title>
</head>

<body>
	<pre>
		<?php
		//create the parser object and call relevant functions
		require('world_data_parser.php');
		$parser = New WorldDataParser();
		//call the printXML function
		$data = $parser->parseCSV("world_data.csv");
		print_r($data);

		?>

	</pre>
</body>
</html>
